import React from 'react'

export default function Notfound() {
  return (
    <div>
        <h2> 404 ! Page Not found</h2>
    </div>
  )
}
