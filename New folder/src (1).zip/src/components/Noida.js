import React from 'react'

export default function Noida() {
  return (
    <div>Noida</div>
  )
}
